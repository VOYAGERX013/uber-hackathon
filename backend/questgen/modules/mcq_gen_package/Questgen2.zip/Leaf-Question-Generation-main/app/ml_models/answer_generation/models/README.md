## Download link

This model has been depricated in the application in favor of the multi-task question-asnwer generation model.
