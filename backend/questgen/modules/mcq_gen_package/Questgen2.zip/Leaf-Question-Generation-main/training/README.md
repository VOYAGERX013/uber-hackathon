## Training on your own
You can download the notebooks directly from there or open the [Question-Answer Generation](https://colab.research.google.com/drive/15GAaD-33jw81sugeBFj_Bp9GkbE_N6E1?usp=sharing) and [Distractor Generation](https://colab.research.google.com/drive/1kWZviQVx1BbelWp0rwZX7H3GIPS7_ZrP?usp=sharing) in Google Colab. 
